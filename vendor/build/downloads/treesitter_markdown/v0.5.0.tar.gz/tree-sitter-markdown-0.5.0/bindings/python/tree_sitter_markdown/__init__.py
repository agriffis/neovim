"Markdown grammar for tree-sitter"

from ._binding import language, inline_language

__all__ = ["language", "inline_language"]
