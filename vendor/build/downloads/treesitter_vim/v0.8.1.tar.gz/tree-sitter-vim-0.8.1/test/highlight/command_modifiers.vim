tab echo "foo"
" <- @keyword
"   ^ @keyword
"        ^ @string

vertical echo "foo"
" <- @keyword
"        ^ @keyword
"              ^ @string

leftabove echo "foo"
" <- @keyword

aboveleft echo "foo"
" <- @keyword

rightbelow echo "foo"
" <- @keyword

belowright echo "foo"
" <- @keyword

topleft echo "foo"
" <- @keyword

botright echo "foo"
" <- @keyword
